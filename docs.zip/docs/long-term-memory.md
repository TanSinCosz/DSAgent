# 长期记忆

## 八、长期记忆（Long-term Memory）

长期记忆基于**文件系统**（Markdown 文件 + 索引），跨会话保留用户偏好、项目约定和重要发现。

涉及文件：

| 文件                              | 行数 | 职责                                                 |
| --------------------------------- | ---- | ---------------------------------------------------- |
| `src/Memory/file-memory.ts`     | 360  | 核心：Markdown 读写、MEMORY.md 索引维护、SHA256 去重 |
| `src/Memory/auto-dream.ts`      | 354  | Dream 合并：从日志到 topic 文件的整理流程            |
| `src/Memory/runtime.ts`         | 103  | 配置默认值（`LongTermMemoryRuntimeConfig`）        |
| `src/query/long-term-memory.ts` | 556  | Query 循环层：注入构建、自动提取调度、文件选择       |
| `src/Tools/MemorySave/`         | ~50  | MemorySave 工具：Agent 调用 →`saveFileMemory()`   |

---

### 8.1 数据结构

#### 8.1.1 磁盘布局

```
~/.opencat/memory/projects/<project-key>/   ← getFileMemoryDir()
├── MEMORY.md                               ← 索引文件（entrypoint）
├── logs/                                   ← 自动提取的原始信号
│   └── YYYY/MM/YYYY-MM-DD.md
├── <slug>-<hash8>.md                       ← topic 记忆文件
└── .dream.lock                             ← Dream 并发锁
```

`project-key` 由 `cwd` 路径通过 `createProjectMemoryKey()` 转换得来：将绝对路径中的盘符、分隔符替换为可读的 key 名。例如 `C:\Users\Administrator\Desktop\opencat-typescirpt` → `C-Users-Administrator-Desktop-opencat-typescirpt-854479bd`（末尾 8 位是路径 hash 的截断）。如果配置了 `fileMemoryDirectory` 环境变量，则直接使用该路径，不推导 project key。

#### 8.1.2 基础常量（`file-memory.ts`）

| 常量 | 值 | 说明 |
|------|-----|------|
| `FILE_MEMORY_BASE_DIR` | `".opencat/memory"` | 长期记忆根目录 |
| `FILE_MEMORY_ENTRYPOINT` | `"MEMORY.md"` | 索引文件名 |
| `FILE_MEMORY_LOGS_DIR` | `"logs"` | 日志子目录 |
| `DEFAULT_MEMORY_TYPE` | `"user"` | 默认记忆类型 |
| `MAX_SCANNED_MEMORY_FILES` | `200` | 单次最多扫描的记忆文件数 |

`ENTRYPOINT_HEADER` — MEMORY.md 模板内容：

```

# Long-term memory

This file is an index. Keep each entry short and put memory details in topic files.

```

路径辅助函数：

- `getFileMemoryDir(runtime)` — 绝对路径。若 `runtime.longTermMemoryConfig.fileMemoryDirectory` 已配置 → 使用配置值；否则 → `join(homedir(), FILE_MEMORY_BASE_DIR, "projects", createProjectMemoryKey(runtime.cwd))`
- `getFileMemoryEntrypointPath(runtime)` — `join(memoryDir, "MEMORY.md")`
- `getFileMemoryLogsDir(runtime)` — `join(memoryDir, "logs")`

#### 8.1.3 记忆文件格式

YAML frontmatter + Markdown 正文。`renderMemoryFile()` 拼接：

```markdown
---
name: "简短标题"
description: "一行描述，用于后续相关性选择"
type: user | feedback | project | reference
hash: <SHA256 of memory content>
reason: "保存原因（可选）"
---
记忆正文内容。
```

辅助函数：

- `hashMemory(memory)` → SHA256 hex
- `slugify(memory)` → 取正文的前 80 个字符，保留 CJK/字母/数字，空格和标点换成 `-`，去首尾连字符，转小写
- `titleFromMemory(memory)` → 取正文的第一句（以 `.`、`！`、`?`、`\n` 等分隔），最长 120 字符
- `descriptionFromMemory(memory)` → 与 title 相同（简洁的一行）
- 文件名 = `${slugify(memory)}-${hash.slice(0, 8)}.md`

四种类型：

| 类型          | 含义                                         |
| ------------- | -------------------------------------------- |
| `user`      | 用户角色、偏好、背景                         |
| `feedback`  | 对工作方式的修正（含 Why + How）             |
| `project`   | 非代码可推导的项目上下文（动机、约束、决策） |
| `reference` | 外部系统指针                                 |

**Frontmatter 解析**（`parseFrontmatter()`）：

- 用正则 `/^---\r?\n([\s\S]*?)\r?\n---/` 匹配 frontmatter 块
- 逐行按 `:` 分割 key:value
- value 经 `parseYamlScalar()` 处理：引号包裹的去掉引号，`"true"`/`"false"` 保持字符串不做 boolean 转换，数字保持字符串
- 返回 `Record<string, string>`
- `stripFrontmatter()` 用 `/^---\r?\n[\s\S]*?\r?\n---\r?\n?/` 删除 frontmatter 块，返回正文

#### 8.1.4 MEMORY.md 索引格式

```markdown
# Long-term memory

This file is an index. Keep each entry short and put memory details in topic files.
- [用户喜欢樊文华。](memory-331717f4.md) - 用户喜欢樊文华。
```

`ensureEntrypointHasLink()` 维护该索引：

1. 读 `MEMORY.md`，不存在则用 `ENTRYPOINT_HEADER` 模板创建
2. 计算 `relative(entrypointDir, memoryPath)` 得到相对路径 link
3. 用 `content.includes(\`](${link})\`)` 检查链接是否已存在（简单 substring 匹配）
4. 不存在 → 追加 `\n- [title](link) - description\n`

#### 8.1.5 核心类型（`file-memory.ts`）

| 类型 | 关键字段 | 说明 |
|------|----------|------|
| `FileMemoryType` | — | `"user" \| "feedback" \| "project" \| "reference"` |
| `SaveFileMemoryInput` | `memory`, `reason?`, `type?` | MemorySave 工具输入，`type` 默认 `"user"` |
| `SaveFileMemoryResult` | `id`, `memory`, `metadata` | `metadata.event`: `"ADD"` 表示新建，`"EXISTS"` 表示去重命中 |
| `FileMemoryHeader` | `filename`, `path`, `name?`, `description?`, `type?` | 扫描时从 frontmatter 解析的元数据 |
| `LoadedFileMemory` | 继承 `FileMemoryHeader` + `content` | 加载后的记忆正文（已 strip frontmatter） |
| `LoadedFileMemoryEntrypoint` | `path`, `content` | MEMORY.md 的加载结果 |

#### 8.1.6 文件扫描与去重

**`scanFileMemoryHeaders()`** — 递归扫描所有 `.md` topic 文件（排除 `MEMORY.md` 和 `logs/` 目录），解析每个文件的 frontmatter，返回 `FileMemoryHeader[]`，最多 200 条。`listMarkdownMemoryFiles()` 递归遍历目录，跳过 `logs` 子目录，按文件名排序。

**`findMemoryByHash()`** — 去重核心：遍历 `memoryDir` 下所有 `.md` 文件（排除 `MEMORY.md`），读取内容，检查 `content.includes(\`hash: ${hash}\`)`。命中 → 返回已存在的文件路径，调用方只更新索引链接，不创建新文件。

**`formatFileMemoryManifest(headers)`** — 将 `FileMemoryHeader[]` 渲染为供选择模型使用的文本清单：

```
- [user] memory-331717f4.md: 用户喜欢樊文华。 - 用户喜欢樊文华。
```

**`loadFileMemories(runtime, filenames)`** — 批量加载指定文件名的记忆：

1. 先调 `scanFileMemoryHeaders()` 获取有效文件列表（防止注入非法路径）
2. 对每个 filename，在 headers 中查找 → 读取文件 → `stripFrontmatter()` → 返回 `LoadedFileMemory[]`

#### 8.1.7 关键常量（`long-term-memory.ts` / `auto-dream.ts`）

| 常量 | 值 | 说明 |
|------|-----|------|
| `MEMORY_QUERY_RECENT_MESSAGES` | 6 | 构建查询时取最近 N 条消息 |
| `MEMORY_QUERY_MAX_CHARS` | 4,000 | 查询字符串最大长度 |
| `MAX_RELEVANT_MEMORY_FILES` | 5 | 每次注入最多选中的文件数 |
| `MEMORY_SELECTOR_MAX_TOKENS` | 512 | 选择模型的输出 token 上限 |
| `FILE_MEMORY_EXTRACTION_MAX_TURNS` | 5 | 提取子 agent 最大轮数 |
| `RECENT_TOOL_NAMES_FOR_MEMORY_QUERY` | 12 | 随 manifest 发给选择器的近期工具数 |
| `MEMORY_DREAM_MAX_TURNS` | 8 | Dream 子 agent 最大轮数 |
| `MEMORY_DREAM_RECENT_SESSION_LIMIT` | 8 | 纳入考虑的最近 transcript 数 |

---

### 8.2 配置

`LongTermMemoryRuntimeConfig`（`src/Memory/runtime.ts`）：

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enabled` | `boolean` | `true` | 长期记忆总开关 |
| `autoInject` | `boolean` | `true` | 每轮自动注入文件记忆 |
| `autoExtract` | `boolean` | `false` | 每轮结束后 fork agent 提取（需用户显式开启） |
| `autoInjectTopK` | `number` | `6` | 自动注入的记忆条目数 |
| `searchThreshold` | `number` | `0.1` | 搜索相关性阈值 |
| `maxInjectedChars` | `number` | `8,000` | 注入内容的最大字符数 |
| `fileMemoryDirectory?` | `string` | — | 覆盖默认 `~/.opencat/memory/` 路径 |
| `userId` | `string` | `"default-user"` | 用户标识 |
| `agentId` | `string` | — | Agent 标识 |
| `runId` | `string` | — | 运行标识 |

`createLongTermMemoryRuntimeConfig()` 从 options 和 identity 中合并默认值。`cli.ts` 和 `web-cli.ts` 中传递的默认配置：`autoInject: true`（注入开启）、`autoExtract: false`（提取关闭，用户需显式开启）。

---

### 8.3 调用链：注入（每轮 query 时）

#### 8.3.1 完整函数调用路径

```
query()                                          // query.ts:76
  → _query()                                     // query.ts:84  (主循环)
    → materializeContextForQuery()                // query.ts:548
      → shouldAttachLongTermMemory(state)         // query.ts:673
          return lastMessage?.role === "user"
              && lastMessage.source === "user"
          // 只在收到真实用户消息时才注入，runtime/system 消息不触发
      → createLongTermMemoryContextMessage(
          runtime, visibleMessages)              // long-term-memory.ts:35
      → createProjectionContextStateMessage()    // runtime-context.ts:88
      → state.Messages.push(contextMessage)      // query.ts:579
```

#### 8.3.2 `createLongTermMemoryContextMessage()` 完整流程

`long-term-memory.ts:35`，执行以下步骤：

1. **检查配置** — 若 `enabled` 或 `autoInject` 为 false，返回 `null`
2. **构建查询** — 调用 `buildLongTermMemoryQuery(messages)` 从最近消息提取查询文本；若为空，跳过
3. **加载入口** — 调用 `loadFileMemoryEntrypoint(runtime)` 读取 MEMORY.md；若不存在，跳过
4. **获取 headers** — 调用 `scanFileMemoryHeaders(runtime)` 获取所有 topic 文件的 frontmatter 元数据
5. **收集防重复信息** — `collectSurfacedLongTermMemoryFiles(messages)` 扫描已注入文件名；`collectRecentToolNames(messages)` 收集最近 12 个工具名
6. **选择文件** — 调用 `selectRelevantFileMemories()`，用 DeepSeek 从 manifest 中挑选 ≤5 个相关文件
7. **加载文件** — 调用 `loadFileMemories(runtime, selectedFiles)` 读取被选中的文件正文
8. **渲染 XML** — 调用 `renderLongTermMemoryFileContext()`，不超过 `maxInjectedChars`
9. **发送遥测** — 发出 `long_term_memory_injected` 事件（含 queryChars、resultCount、injectedChars）
10. 返回 `{ role: "user", content }` — 任何异常静默捕获并返回 `null`，记忆注入失败不阻塞主流程

#### 8.3.3 `buildLongTermMemoryQuery()`

`long-term-memory.ts:472`，从消息历史构建查询字符串：

1. **过滤消息** — `isLongTermMemorySourceMessage()`：保留 role 为 `user`/`assistant`、source 为 `user`/`assistant`、且有文本内容的消息
2. **取最近 6 条**
3. **格式化** — 每条格式化为 `role: text` 行，用 `getMessageText()` 提取文本（user → `content`，assistant → string 类型的 `content`）
4. **截断** — `truncate()` 到 `MEMORY_QUERY_MAX_CHARS`（4,000 字符）

#### 8.3.4 `selectRelevantFileMemories()` — 文件选择器

这是整个注入流程的核心：用一个轻量的 DeepSeek 调用从 manifest 中挑选相关文件。

`long-term-memory.ts:91`，执行以下步骤：

1. 从 headers 中排除本轮已注入过的文件（通过 `alreadySurfaced` 集合）
2. 若无可用文件 → 返回空数组
3. 调用 `formatFileMemoryManifest()` 将 headers 渲染为文本清单
4. 若提供了近期工具名，追加 `Recently used tools: ...` 提示
5. 调用 DeepSeek（`deepseek-v4-flash`，temperature=0，JSON mode，`thinking: disabled`，max_tokens=512），传入：

   **System prompt：**
   ```
   You are selecting long-term memory files that will be useful to OpenCat as it processes the user's next request.
   You will be given the user's recent query context and a manifest of available memory files with their filenames, types, names, and descriptions.
   Return JSON only: {"selected_files":["relative/path.md"]}.
   Return a list of filenames for memories that will clearly be useful to OpenCat as it processes the request, up to 5 files.
   Only select filenames from the provided manifest.
   Select based on the manifest metadata. Do not invent filenames or rely on memories that are not listed.
   Only include memories you are certain will help. If you are unsure whether a memory is useful, do not include it.
   Be selective and discerning; keyword overlap alone is not enough.
   If recently used tools are provided, do not select ordinary usage reference memories for those tools because active tool output already provides usage context. Still select memories containing warnings, gotchas, or known issues about those tools.
   If no listed memory is clearly useful, return an empty list.
   ```

   **User prompt：** 包含查询文本、可用文件 manifest、以及工具提示。

6. 解析 JSON 响应 → 过滤（只保留 manifest 中确实存在的文件名） → 截断到最多 `MAX_RELEVANT_MEMORY_FILES`（5）个

**辅助函数：**
- `parseSelectedFiles(content)` — `JSON.parse(extractJsonObject(content)).selected_files`，取 string[] 部分，容错返回空数组
- `extractJsonObject(content)` — 取 `{` 到 `}` 之间的子串
- `collectSurfacedLongTermMemoryFiles(messages)` — 扫描所有消息的 content 字段，用正则 `/<memory_file\s+path="([^"]+)"/g` 提取已注入过的文件名，返回 `Set<string>`
- `collectRecentToolNames(messages)` — 从最近消息中遍历 tool 消息和 assistant tool_calls，收集最近 12 个唯一的工具名

#### 8.3.5 `renderLongTermMemoryFileContext()` — XML 渲染

`long-term-memory.ts:501`，将入口文件和选中的记忆组装为 XML 块：

1. 生成 `<long_term_memory>` 开头 + 使用提示
2. 嵌入 `<memory_index>`（含 source 路径和 MEMORY.md 全文）
3. 若有选中文件 → 嵌入 `<memory_files>`，每个文件为 `<memory_file path="..." type="...">正文</memory_file>`
4. 关闭 `</long_term_memory>`
5. `truncate()` 到 `maxChars`，超长则追加 `\n[Long-term memory truncated]`

`escapeAttribute()` 对 `&` `"` `<` `>` 做 XML 转义。

#### 8.3.6 注入的 XML 最终形态

```xml
<long_term_memory>
Relevant long-term memories for this request.
Use them as context, but prefer newer user messages if there is a conflict.
<memory_index>
source=C:\Users\...\MEMORY.md
# Long-term memory

This file is an index. Keep each entry short and put memory details in topic files.
- [用户喜欢樊文华。](memory-331717f4.md) - 用户喜欢樊文华。
</memory_index>
<memory_files>
<memory_file path="memory-331717f4.md" type="user">
用户喜欢樊文华。
</memory_file>
</memory_files>
</long_term_memory>
```

该块被 `createProjectionContextStateMessage()` 包装进 `<opencat_context>` 的 `<context_block source="long_term_memory">` 中，与其他运行时上下文（Plan、Todo、Agent 通知）一起追加到 `state.Messages` 末尾。整个注入链路中任何异常都被静默捕获。

---

### 8.4 调用链：MemorySave（显式保存）

#### 8.4.1 工具定义

`MemorySave` 是 `alwaysLoad: true` 的 always-available 工具。其 schema：

```typescript
// 输入
z.strictObject({
  memory: z.string().min(1)
    .describe("The exact durable memory the user asked to add. Prefer one fact per call."),
  memoryType: z.enum(["user", "feedback", "project", "reference"]).optional()
    .describe("Optional memory category. Defaults to user."),
  reason: z.string().optional()
    .describe("Short reason this memory should be durable, when useful for auditing."),
});

// 输出
z.object({
  results: z.array(z.object({
    id: z.string(), memory: z.string(),
    metadata: z.record(z.string(), z.any()).optional(),
  })),
});
```

工具 prompt 明确约束：

> "Use this only when the user explicitly asks you to remember, save, or add something to memory."
> "Do not call this for ordinary conversation, transient task progress, or memory lookup."
> "Do not save secrets or sensitive information unless the user explicitly asks."

#### 8.4.2 `saveFileMemory()` 完整流程

`file-memory.ts:59`，执行以下步骤：

1. **门检查** — 若 `longTermMemoryConfig.enabled` 为 false 或 `memory` 为空 → 返回空结果
2. **确保目录存在** — `mkdir(memoryDir, { recursive: true })`
3. **去重检查** — 计算 SHA256 hash → 调用 `findMemoryByHash()` 检查是否已存在同 hash 文件
4. **已存在 → 只更新索引** — 调用 `ensureEntrypointHasLink()` 追加 MEMORY.md 链接；返回 `event: "EXISTS"`
5. **不存在 → 创建新文件** — 生成文件名 `${slugify(memory)}-${hash.slice(0, 8)}.md`；调用 `writeFile()` 写入带 frontmatter 的完整记忆文件
6. **更新 MEMORY.md 索引** — 调用 `ensureEntrypointHasLink()`
7. 返回 `event: "ADD"` + 文件路径、hash、type 等元数据

#### 8.4.3 结果格式化

```typescript
// MemorySave.formatResult()
formatResult({ output }: { output: MemorySaveOutput }): string {
  if (output.results.length === 0) return "No long-term memory was saved.";
  return [
    `Saved ${output.results.length} long-term memor${output.results.length === 1 ? "y" : "ies"}.`,
    ...output.results.map(result => `- ${result.id}: ${result.memory}`),
  ].join("\n");
}
```

---

### 8.5 调用链：自动提取（autoExtract）

#### 8.5.1 触发位置与条件

入口：`query.ts:220` — 模型本轮无工具调用时（即本轮可以结束），调用 `extractLongTermMemoryForCompletedQuery(runtime, state, { turnStartMessageId, turnStartedAt })`。

四道门（`long-term-memory.ts:233`）：

1. **门 1: 只有主 Agent** — `agentRole !== "main"`、`enabled` 为 false、或 `autoExtract` 为 false → 跳过
2. **门 2: 本轮有新消息** — `selectTurnMessagesFromMessages()` 从 `turnStartMessageId` 或最近一条用户消息开始提取，若无新消息 → 跳过
3. **门 3: 本轮未显式保存过** — `hasMemorySaveSince()` 检查从本轮起点以来是否有 MemorySave 调用，若有 → 跳过（互斥保护）
4. **Fire-and-forget** — 不 await，直接调用 `runFileMemoryExtractionAgent()`；异常通过遥测事件上报

**辅助函数：**
- `selectTurnMessagesFromMessages()` — 从 `turnStartMessageId` 或最近用户消息位置开始切片，用 `isLongTermMemorySourceMessage()` 过滤
- `hasMemorySaveSince()` — 从起始位置检查是否有 assistant 消息包含 `MemorySave` tool_call

#### 8.5.2 `runFileMemoryExtractionAgent()` — Fork 子 Agent

`long-term-memory.ts:268`，执行以下步骤：

1. 获取 `memoryDir` 和 `logsDir`，确保 `logsDir` 目录存在
2. 调用 `buildFileMemoryExtractionPrompt()` 构建提取 prompt（详见 8.5.4）
3. 动态 import `runAgentTask`，以 fork 模式启动子 agent：
   - `agentDefinition`: `createFileMemoryExtractionAgentDefinition()`（详见 8.5.3）
   - `maxTurns`: 5
   - `mode`: `"fork"`，`isolation`: `"none"`（继承父上下文）
   - `agentRole`: `"session"`，`recordTaskLifecycle`: `false`
   - `forkContextMessages`: 父 state 中全部消息的浅拷贝
   - `canUseTool`: 沙箱限制写入只能在 `logsDir` 内

#### 8.5.3 Agent 定义与沙箱

**Agent 定义**（`createFileMemoryExtractionAgentDefinition()`）：

| 属性 | 值 |
|------|-----|
| `agentType` | `"long_term_memory"` |
| `category` | `"worker"`，`source`: `"built-in"` |
| `tools` | `Read`, `Grep`, `Glob`, `Edit`, `Write` |
| `disallowedTools` | `Agent`, `Bash`, `MemorySave`, `SendMessage`, `Plan`, `TodoWrite`, `WebSearch`, `WebFetch`, `ReadSkill` |
| `model` | `"inherit"` |
| `permissionMode` | `"default"` |
| `maxTurns` | `FILE_MEMORY_EXTRACTION_MAX_TURNS`（5） |

System prompt 核心指令：只追加日志、不回答用户、不修改项目文件、不编辑 MEMORY.md 或 topic 文件（留给 Dream 整合）。

**沙箱**（`createFileMemoryExtractionCanUseTool(logsDir)`）：
- `Read` / `Grep` / `Glob` → 允许任意路径
- `Write` / `Edit` → 必须 `file_path` 在 `logsDir` 内（用 `isPathInside()` 做路径归属检查：normalize + resolve 后比较前缀）
- 其他 → deny

#### 8.5.4 提取 Agent 的 Prompt（完整）

`buildFileMemoryExtractionPrompt()` 产出的 prompt：

```
分析继承对话中最近约 N 条模型可见消息，如有价值则追加持久记忆信号。

记忆目录：<memoryDir>
每日日志目录：<logsDir>
当天追加日志文件：<logPath>

可用工具：Read、Grep、Glob、Edit、Write。
只能对每日日志目录内的文件进行 Write/Edit 操作，其他写入将被拒绝。
不要编辑 MEMORY.md 或 topic 记忆文件，后续的手动/自动 Dream 流程会整合日志。
如果日志文件已存在，在末尾追加新的条目。不要重写或重新整理已有条目。
如果日志文件不存在，创建它及必要的父目录。

日志格式：
```markdown
- HH:MM [type] 简洁的持久记忆信号。如有用，包含 Why/How 来指导应用方式。
```

尽可能使用当前本地时间，否则使用近似时间戳。

只记录对未来对话可能有用的信息：

- user：持久的用户角色、目标、偏好、知识背景。
- feedback：关于工作方式的修正或经过验证的偏好。
  当对话中提供了 Why 和 How 时一并记录。
- project：非显而易见的项目上下文、动机、约束、截止日期，
  或无法从代码/git 中推导的决策。将相对日期转换为绝对日期。
- reference：指向外部系统的指针以及在哪里查找最新信息。

不应保存的内容：

- 代码模式、约定、架构、文件路径或项目结构
- Git 历史、最近的变更记录或谁改了什么
- 调试方案或修复配方
- 项目文件中已有文档记录的任何内容
- 临时任务细节：进行中的工作、临时状态、当前对话上下文
- 当前对话的计划或任务清单

这些日志条目是原始信号，不是正式记忆。保持保守：
如果没有持久性的内容出现，不要写入任何内容。
如果无需保存任何内容，不要调用任何写入工具，
用简短说明表示不需要持久记忆即可结束。

```

#### 8.5.5 日志路径

`getDailyMemoryLogPath(logsDir, date)` — 将日期格式化为 `logsDir/YYYY/MM/YYYY-MM-DD.md` 路径。

例如 `~/.opencat/memory/.../logs/2026/01/2026-01-15.md`

---

### 8.6 调用链：Dream 合并（手动）

#### 8.6.1 完整流程

入口：`runMemoryDream()`（`auto-dream.ts:52`）：

```
runMemoryDream(runtime, state, { recentSessionLimit?: number })
  │
  ├─ 1. !enabled → skip (reason: "disabled")
  │
  ├─ 2. acquireMemoryDreamLock(memoryDir)
  │      → fs.open(lockPath, "wx") — 独占创建
  │      → 写入 PID + startedAt JSON
  │      → 已存在 → skip (reason: "locked")
  │
  ├─ 3. scanFileMemoryHeaders(runtime) → 现有 topic 文件清单
  │
  ├─ 4. listRecentMemoryDreamTranscripts(runtime, limit)
  │      → 从 runtime.cwd/.opencat/transcripts/ 读取 .jsonl 文件
  │      → 按 mtime 降序排序 → 取最近 8 个
  │      → 返回 { filename, path, modifiedAt, sizeBytes }[]
  │
  ├─ 5. runAgentTask():
  │      agentType: "memory_dream"
  │      maxTurns: MEMORY_DREAM_MAX_TURNS (8)
  │      mode: "fork"
  │      isolation: "none"
  │      recordTaskLifecycle: false
  │      agentRole: "session"
  │      prompt: buildMemoryDreamPrompt(...)  ← 四阶段
  │      agentDefinition:
  │        tools: ["Read", "Grep", "Glob", "Edit", "Write"]
  │        disallowed: ["Agent","Bash","MemorySave","SendMessage",
  │                      "Plan","TodoWrite","WebSearch","WebFetch","ReadSkill"]
  │        model: "inherit"
  │        systemPrompt: "You are a forked memory dream agent.
  │                        Your only job is to consolidate file-based long-term memory.
  │                        Do not answer the user and do not modify project files.
  │                        Write only inside the memory directory."
  │      canUseTool: Read/Grep/Glob 不限; Write/Edit 只能写 memoryDir 下
  │
  ├─ 6. 返回 MemoryDreamResult:
  │      { status: "completed", result, agentId, messageCount }
  │      或 { status: "failed", reason }
  │
  └─ 7. finally: lock.release() → rm .dream.lock
```

#### 8.6.2 Dream Prompt（完整）

`buildMemoryDreamPrompt()` 产出的完整 prompt：

```
# Dream：记忆整合

你正在执行一次手动 Dream：对 OpenCat 文件式长期记忆进行的反思整理。
将最近记录的记忆信号合成为持久、组织良好的 topic 记忆，
使后续会话能够快速定位上下文。

记忆目录：<memoryDir>
每日日志目录：<logsDir>
会话 transcript 目录：<transcriptDir>
入口索引：MEMORY.md
当前日期：<YYYY-MM-DD>

你可以使用 Read、Grep、Glob 来检查记忆文件。
只能对记忆目录内的文件进行 Edit/Write 操作。
编辑或覆盖已有文件前必须先读取该文件。

## 已有记忆清单
<formatFileMemoryManifest 输出，或 "(没有找到 topic 记忆文件。)" >

## 最近的会话 transcript
<formatMemoryDreamTranscriptManifest 输出，或 "(没有找到最近的会话 transcript 文件。)" >

## 阶段 1 - 定位
- 检查记忆目录，如存在则读取 MEMORY.md。
- 浏览已有 topic 文件，以便进行更新而非创建近似重复项。
- 如果存在 logs/，查看最近的每日日志条目。日志是原始信号，不是正式记忆。

## 阶段 2 - 收集最近的信号
寻找值得持久化的新信息。按优先级排列的来源：
1. logs/YYYY/MM/YYYY-MM-DD.md 下的每日日志（如存在）。
2. 已有记忆中变得陈旧、与较新事实矛盾或需要清理的部分。
3. 上述最近的会话 transcript，仅当日志和 topic 文件提供的信息不足时使用。
- 寻找对未来对话有价值的用户偏好、反馈、项目上下文和外部引用。
- 不要穷举式地阅读 transcript JSONL 文件。使用精准关键词搜索，
  仅检查匹配区域。
- 不要保留 transcript 中的临时任务进度，除非它揭示了持久的用户偏好或项目规则。

## 阶段 3 - 整合
- 在记忆目录顶层写入或更新 topic 记忆文件。
- 使用以下 frontmatter 格式：
  ```markdown
  ---
  name: {{记忆名称}}
  description: {{用于后续相关性选择的一行描述}}
  type: {{user | feedback | project | reference}}
  ---

  {{记忆正文}}
  ```

- 将新信号合并到已有 topic 文件中，而非创建重复项。
- 尽可能将相对日期转换为绝对日期。
- 如果记忆已过时、错误或被替代，修正或删除它。
- 保持 feedback/project 记忆具有可操作性；当来源提供了 Why 和 How 时一并包含。

## 不应保存的内容

- 可从仓库中推导的代码结构、文件路径、架构事实或项目约定。
- Git 历史、最近的变更、临时任务进度、当前计划或待办清单。
- 属于代码、测试、提交或文档范畴的调试配方。
- 项目文件中已有文档记录的任何内容，除非用户将其作为跨会话偏好明确提出。

## 阶段 4 - 清理与索引

- 将 MEMORY.md 更新为简洁的索引。
- 每条索引占一行：- [标题](文件.md) - 一行概要。
- 永远不要将完整记忆正文放入索引。
- 移除指向过时、错误、已删除或被替代记忆的指针。
- 保持索引简短并对后续相关性选择有用。

返回你整合、更新、清理了哪些内容的简要总结，或说明为什么没有变化。

```

#### 8.6.3 锁机制

`acquireMemoryDreamLock(memoryDir)` — 用文件锁防止并发 Dream：

1. 确保 `memoryDir` 存在
2. 用 `fs.open(lockPath, "wx")` 尝试独占创建 `.dream.lock`
3. 写入 PID 和开始时间（ISO 格式 JSON）
4. 若文件已存在（创建失败）→ 返回 `{ acquired: false }`
5. 若创建成功 → 返回 `{ acquired: true, release() }`，其中 `release()` 调用 `rm(lockPath, { force: true })` 删除锁文件

#### 8.6.4 Transcript 目录

- `getMemoryDreamTranscriptDir(runtime)` → 返回 `runtime.cwd/.opencat/transcripts`
- `formatMemoryDreamTranscriptManifest(transcripts, transcriptDir)`:
  - 若 transcript 列表为空 → 返回 `"(No recent session transcript files were found.)"`
  - 否则每条格式化为 `- relative/path (size bytes, modified timestamp)`

---

### 8.7 数据流全景图

```
                         ┌──────────────────────┐
                         │   用户说 "记住xxx"    │
                         └──────────┬───────────┘
                                    │
                                    ▼
                         ┌──────────────────────┐
                         │  MemorySave.call()   │
                         │  → saveFileMemory()  │
                         │  → SHA256 去重       │
                         │  → 写 .md + 更新索引 │
                         └──────────┬───────────┘
                                    │
                                    ▼
     ┌──────────────────────────────────────────────────────────┐
     │              ~/.opencat/memory/projects/<key>/           │
     │  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐  │
     │  │ MEMORY.md   │  │ *.md topic   │  │ logs/YYYY/MM/  │  │
     │  │ (索引)      │  │ files        │  │ YYYY-MM-DD.md  │  │
     │  └──────┬──────┘  └──────┬───────┘  └───────┬────────┘  │
     └─────────┼────────────────┼──────────────────┼───────────┘
               │                │                  │
    ┌──────────▼────────────────▼──────────────────▼───────────┐
    │                    每轮注入 (autoInject)                  │
    │  createLongTermMemoryContextMessage()                    │
    │    → 读 MEMORY.md                                       │
    │    → DeepSeek (JSON mode) 选 ≤5 个相关文件               │
    │    → loadFileMemories() 读取正文                        │
    │    → 渲染 <long_term_memory> XML                        │
    │    → 注入到 <opencat_context>                          │
    └──────────────────────────────────────────────────────────┘
                                    │
    ┌───────────────────────────────▼──────────────────────────┐
    │              每轮结束 (autoExtract, 默认关闭)             │
    │  extractLongTermMemoryForCompletedQuery()                │
    │    → fork agent (Read+Grep+Glob+Edit+Write)              │
    │    → 仅追加到 logs/YYYY/MM/YYYY-MM-DD.md                │
    │    → fire-and-forget, 不阻塞主流程                       │
    └──────────────────────────────────────────────────────────┘
                                    │
    ┌───────────────────────────────▼──────────────────────────┐
    │              Dream 合并 (手动: runMemoryDream)            │
    │  fork agent → 四阶段:                                    │
    │    Phase 1: Orient (读现有文件)                          │
    │    Phase 2: Gather (日志 → 新信号)                       │
    │    Phase 3: Consolidate (合并/新建 topic .md)            │
    │    Phase 4: Prune (更新 MEMORY.md 索引)                  │
    └──────────────────────────────────────────────────────────┘
```

---

### 8.8 与技能通知系统的区别

| 维度     | 技能通知（`<dynamic_skills>`）                          | 长期记忆（`<long_term_memory>`）                 |
| -------- | --------------------------------------------------------- | -------------------------------------------------- |
| 数据来源 | 项目中的`.claude/skills/SKILL.md`                       | `~/.opencat/memory/` 下的 Markdown 文件          |
| 触发方式 | FileRead/Write/Edit 后扫描文件系统发现                    | 每轮用户消息时自动注入（`autoInject`）           |
| 注入选择 | 全量（所有活跃技能都注入）                                | DeepSeek 模型选择 ≤5 个最相关的文件               |
| 内容性质 | 技能指令（操作指南、约束规则）                            | 事实性记忆（偏好、决策、知识点）                   |
| 写入方式 | 手动创建/编辑 SKILL.md                                    | MemorySave 工具 / autoExtract / Dream              |
| 跨会话   | 取决于项目文件是否存在                                    | 持久化（在 home 目录，跨项目独立）                 |
| 注入位置 | `state.runtimeContextMessages` → `<opencat_context>` | `<opencat_context>` 中独立的 `<context_block>` |

---

### 8.9 当前未实现

| 待实现               | 说明                                                                           |
| -------------------- | ------------------------------------------------------------------------------ |
| 记忆更新/删除        | `saveFileMemory` 只能 add 不能 modify/delete；需手动编辑 .md 或等 Dream 清理 |
| Dream 自动调度       | `runMemoryDream()` 必须显式调用，没有 cron、timer 或 turn-count 触发         |
| autoExtract 默认关闭 | 自动提取需要用户显式开启`autoExtract: true`；大多数用户不会主动开            |
| 跨记忆引用           | topic 文件之间没有引用关系；Dream 发现两个文件应该合并时，需要手动判断         |

---

---

← [返回 ARCHITECTURE.md 目录](../ARCHITECTURE.md)